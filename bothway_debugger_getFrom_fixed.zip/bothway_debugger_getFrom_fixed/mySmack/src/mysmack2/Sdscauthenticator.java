package mysmack2;

public class Sdscauthenticator {

}
