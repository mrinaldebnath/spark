package mysmack2;

public class Authchallengemessage {
    String fullUserName;
    String MessageDigestEncrypted;
    
    
    
    public Authchallengemessage() {
		super();
	}

	public Authchallengemessage(String fullUserName, String messageDigestEncrypted) {
        this.fullUserName = fullUserName;
        this.MessageDigestEncrypted = messageDigestEncrypted;
    }

    public String getFullUserName() {
        return fullUserName;
    }

    public void setFullUserName(String fullUserName) {
        this.fullUserName = fullUserName;
    }

    public String getMessageDigestEncrypted() {
        return MessageDigestEncrypted;
    }

    public void setMessageDigestEncrypted(String messageDigestEncrypted) {
        MessageDigestEncrypted = messageDigestEncrypted;
    }
}
