package mysmack2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

import org.igniterealtime.restclient.RestApiClient;
import org.igniterealtime.restclient.entity.AuthenticationToken;
import org.igniterealtime.restclient.entity.UserEntity;

import com.fasterxml.jackson.databind.ObjectMapper;




public class Appsmack {
public static void main(String[] args) {
		
		Sdscclient c = new Sdscclient();
	
		
		//myObjectMapper.setVisibility(JsonMethod.FIELD, Visibility.ANY);

		// Enter your login information here
		
		
		
		String username=null;
		String password=null;
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		try {
			
			System.out.println("Enter username: ");
			username=br.readLine();
			
			System.out.println("Enter password: ");
			password=br.readLine();
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			c.login(username, password);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// Display online users
		
		c.startRunning();

		
		/*AuthenticationToken authenticationToken = new AuthenticationToken("admin", "admin");

        RestApiClient restApiClient = new RestApiClient("http://mangodsip.com", 9090, authenticationToken);
	
        
        
        System.out.println(restApiClient.getUser("mrinal").getEmail());
		
		System.exit(0);*/
	
		
	}
}
