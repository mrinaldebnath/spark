package mysmack2;

import org.jivesoftware.smack.AbstractXMPPConnection;
import org.jivesoftware.smack.PacketCollector;
import org.jivesoftware.smack.filter.AndFilter;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;

public class receiverThread implements Runnable {

	Sdscclient c;
	AbstractXMPPConnection connection;
	String talkTo;

	public receiverThread(Sdscclient c, AbstractXMPPConnection connection1, String talkTo) {
		super();
		this.c = c;
		this.connection = connection1;
		this.talkTo = talkTo;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		AndFilter filter = new AndFilter(new PacketTypeFilter(Message.class));
		PacketCollector collector = connection.createPacketCollector(filter);

		while (true) {

			Packet packet = collector.pollResult();

			if (packet != null) {
				if (packet instanceof Message) {
					Message message = (Message) packet;
					if (message != null && message.getBody() != null && message.getFrom().startsWith(talkTo)
							&& message.getType().toString().equals("chat")) {

						System.out.println(message.getFrom() + " says : " + message.getBody());

					}
				}

			}

		}
	}
}
