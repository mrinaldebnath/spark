package mysmack2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.jivesoftware.smack.AbstractXMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.SmackException.NotConnectedException;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;

public class senderThread implements Runnable{
	
	Sdscclient c;
	String talkTo;
	
	

	public senderThread(Sdscclient c, String talkTo) {
		super();
		this.c = c;
		this.talkTo = talkTo;
	}



	@Override
	public void run() {
		// TODO Auto-generated method stub
		String msg=null;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		while (true) {

				try {

					if ((msg = br.readLine()) != null) {
						if (msg.equals("bye"))
							break;

						try {
							c.sendMessage(msg, talkTo);
						} catch (NotConnectedException | XMPPException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		
	}

}
