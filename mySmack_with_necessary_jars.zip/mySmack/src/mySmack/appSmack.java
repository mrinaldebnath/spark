package mySmack;



public class appSmack {
public static void main(String[] args) {
		
		SDSCClient c = new SDSCClient();
		
		

		// Enter your login information here
		try {
			c.login("mrinal", "mrinal");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// Display online users
		c.displayBuddyList();
		
		c.sendingAndReceiving(c);

		c.disconnect();
		System.exit(0);
	
		
	}
}
